# Suzumi-API

一个简单易用的随机图片API！

具体使用方法请查看项目`docs`文件夹，这是一个完整的docs文档！